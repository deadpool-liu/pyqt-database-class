import sys
import time
import numpy as np
from matplotlib.backends.qt_compat import QtCore, QtWidgets
from matplotlib.backends.backend_qt5agg import (FigureCanvas, NavigationToolbar2QT as NavigationToolbar)
from matplotlib.figure import Figure
import matplotlib.pyplot as plt

import sys
from PyQt5.QtCore import *
from PyQt5.QtGui import *
from PyQt5.QtWidgets import *
from PyQt5 import QtWidgets
from sql.MySQL import Database


plt.rcParams['font.family'] = ['sans-serif']
plt.rcParams['font.sans-serif'] = ['SimHei']


class Gui(QWidget):
    def __init__(self, parent=None):
        # super(Gui, self).__init__()
        super().__init__()
        self.database = Database()
        self.setWindowTitle("桥梁信息管理系统")
        self.setWindowIcon(QIcon('./image/logo.ico'))
        self.resize(1600, 800)

        self.layout = QHBoxLayout()  # 水平布局

        ########################################################################################################################
        # layout1 内部的小窗口
        self.layout11 = QFormLayout()
        # self.layout1.setColumnStretch(3, 1)
        # self.layout1.setRowStretch(10, 1)

        self.btn_refresh = QPushButton("刷新")
        # self.btn_excute.setIcon(QIcon(QPixmap("./images/python.png")))
        self.btn_refresh.clicked.connect(self.show_bridge)
        self.layout11.addWidget(self.btn_refresh)

        self.edit_operation = QLineEdit()
        self.edit_operation.setPlaceholderText("操作名称：a:新增桥梁，d:删除桥梁")
        # 设置获取焦点
        # self.edit_operation.setFocus()

        self.edit_bridge_name = QLineEdit()
        self.edit_bridge_name.setPlaceholderText("桥梁名称")
        # 设置显示效果
        # self.edit_operation.setEchoMode(QLineEdit.Normal)
        # self.edit_bridge_name.setEchoMode(QLineEdit.Password)  # QLineEdit.PasswordEchoOnEdit,QLineEdit.Password,QLineEdit.NoEcho

        self.edit_address = QLineEdit()
        self.edit_address.setPlaceholderText("桥梁位置（删除可不填）")

        self.edit_password_1 = QLineEdit()
        self.edit_password_1.setPlaceholderText("正确输入管理员密码后执行的操作才有效。")
        self.edit_password_1.setEchoMode(QLineEdit.Password)

        self.layout11.addRow("操作", self.edit_operation)
        self.layout11.addRow("桥梁名称", self.edit_bridge_name)
        self.layout11.addRow("桥梁位置", self.edit_address)
        self.layout11.addRow("管理员密码", self.edit_password_1)

        self.btn_excute = QPushButton('执行')
        # self.btn_excute.setIcon(QIcon(QPixmap("./images/python.png")))
        self.btn_excute.clicked.connect(self.check_password)
        self.layout11.addWidget(self.btn_excute)

        # layout1 内部的小窗口
        self.layout12 = QFormLayout()

        self.edit_info0 = QLineEdit()
        self.edit_info0.setPlaceholderText("桥梁名字")

        self.edit_info1 = QLineEdit()
        self.edit_info1.setToolTip("文字和评分之间请用 == 号分隔开，否则输入无效")
        self.edit_info1.setPlaceholderText("桥墩情况及评分")

        self.edit_info2 = QLineEdit()
        self.edit_info2.setToolTip("文字和评分之间请用 == 号分隔开，否则输入无效")
        self.edit_info2.setPlaceholderText("桥面情况及评分")

        self.edit_info3 = QLineEdit()
        self.edit_info3.setToolTip("文字和评分之间请用 == 号分隔开，否则输入无效")
        self.edit_info3.setPlaceholderText("护栏情况及评分")

        self.edit_info4 = QLineEdit()
        self.edit_info4.setToolTip("文字和评分之间请用 == 号分隔开，否则输入无效")
        self.edit_info4.setPlaceholderText("桥面排水及评分")

        self.edit_info5 = QLineEdit()
        self.edit_info5.setToolTip("文字和评分之间请用 == 号分隔开，否则输入无效")
        self.edit_info5.setPlaceholderText("桥梁高度及评分")

        self.edit_info6 = QLineEdit()
        self.edit_info6.setToolTip("文字和评分之间请用 == 号分隔开，否则输入无效")
        self.edit_info6.setPlaceholderText("桥梁卫生及评分")

        self.edit_password_2 = QLineEdit()
        self.edit_password_2.setPlaceholderText("正确输入管理员密码后执行的操作才有效。")
        self.edit_password_2.setEchoMode(QLineEdit.Password)

        self.btn_submit = QPushButton('提交')
        self.btn_submit.clicked.connect(self.check_password)

        self.layout12.addRow("桥梁名字", self.edit_info0)
        self.layout12.addRow("桥墩情况", self.edit_info1)
        self.layout12.addRow("桥面情况", self.edit_info2)
        self.layout12.addRow("护栏情况", self.edit_info3)
        self.layout12.addRow("桥面排水", self.edit_info4)
        self.layout12.addRow("桥梁高度", self.edit_info5)
        self.layout12.addRow("桥梁卫生", self.edit_info6)
        self.layout12.addRow("管理密码", self.edit_password_2)
        self.layout12.addWidget(self.btn_submit)

        ########################################################################################################################
        self.layout1 = QVBoxLayout()

        self.layout1.addLayout(self.layout11)
        self.layout1.addLayout(self.layout12)

        ########################################################################################################################
        self.layout2 = QHBoxLayout()
        self.text_browser = QTextBrowser()
        self.text_browser.setToolTip("按刷新键重新加载刷新表名")

        # self.text_browser.resize(300, 700)
        self.layout2.addWidget(self.text_browser)
        ########################################################################################################################
        self.layout3 = QVBoxLayout()
        self.figure = Figure()
        self.figCanvas = FigureCanvas(self.figure)
        self.tool_Bar = NavigationToolbar(self.figCanvas, self)
        self.paint = self.figCanvas.figure.subplots()

        self.layout3.addWidget(self.figCanvas)
        self.layout3.addWidget(self.tool_Bar)
        ########################################################################################################################

        self.layout.addLayout(self.layout1)
        self.layout.addLayout(self.layout2)
        self.layout.addLayout(self.layout3)

        self.setLayout(self.layout)

        # self.yesterday =

    def whichbtn(self, btn):
        print("clicked button is " + btn.text())
        self.database.test()

    def check_password(self):
        if self.edit_password_1.text() == "1":
            print("password_1 is right !")

            if self.edit_operation.text() == "a":
                self.database.create_bridge_table(self.edit_bridge_name.text(), self.edit_address.text())
            elif self.edit_operation.text() == "d":
                self.database.delete_bridge_table(self.edit_bridge_name.text())

            self.edit_password_1.clear()
            self.show_message()
        elif self.edit_password_2.text() == "1":
            print("password_2 is right !")
            self.database.add_new_information_by_hand(self.edit_info0.text(), self.edit_info1.text(),
                                                      self.edit_info2.text(), self.edit_info3.text(),
                                                      self.edit_info4.text(), self.edit_info5.text(),
                                                      self.edit_info6.text())
            self.edit_password_2.clear()
            self.show_message()
        else:
            print("密码不正确，请重试。")

    def show_message(self):
        QtWidgets.QMessageBox.information(self, "提示", "已成功执行操作", QtWidgets.QMessageBox.Ok)

    def show_bridge(self):
        self.text_browser.clear()
        self.text_browser.append("==桥名称==")
        bridges = self.database.show_tables()
        for i in bridges:
            self.text_browser.append(i)

        self.drag_graph()
        # for i in range(5):
        #     self.text_browser.append("123")

    def drag_graph(self):
        # print("11111111111111")
        data = self.database.get_recent_rating()
        self.paint.clear()
        self.paint.bar(data[0], data[1], color=data[2])
        self.paint.figure.canvas.draw()


if __name__ == "__main__":
    app = QApplication(sys.argv)
    gui = Gui()
    gui.show()
    sys.exit(app.exec_())
