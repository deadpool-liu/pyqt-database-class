import re
import pymysql


class Database:
    def __init__(self):
        self.coon = pymysql.connect("localhost", "root", "root", "bridge", charset='gbk')
        self.cur = self.coon.cursor()
        print("sql has loaded")

########################################################################################################################
    # new bridge
    def create_bridge_table(self, name, address):
        if self.check_if_bridge_exit(name):
            print("该桥梁已经存在，不可编辑。")
        else:

            sentence_c = """create table %s(
                        桥墩情况    varchar(1000),
                        桥面情况    varchar(1000),
                        护栏情况    varchar(1000),
                        桥面排水    varchar(1000),
                        桥梁高度    varchar(1000),
                        桥墩卫生    varchar(1000),
                        桥梁位置    varchar(100)
            );""" % name
            self.cur.execute(sentence_c)
            print("%s表已成功创建！" % name)

            data1 = "良好==10"
            data2 = "良好==10"
            data3 = "良好==10"
            data4 = "良好==10"
            data5 = "良好==10"
            data6 = "良好==10"
            data7 = address
            values = (data1, data2, data3, data4, data5, data6, data7)
            sentence_a = 'insert into %s(桥墩情况, 桥面情况, 护栏情况, 桥面排水, 桥梁高度, 桥墩卫生, 桥梁位置)' % name +\
                         'values(%s, %s, %s, %s, %s, %s, %s) '
            # print(sentence_a)
            self.cur.execute(sentence_a, values)

            print("已成功创建桥梁信息。")
        self.data_commit()
        self.show_tables()

    def delete_bridge_table(self, name):
        if self.check_if_bridge_exit(name):
            sql = "DROP TABLE %s" % name
            self.cur.execute(sql)
            print("%s表已成功删除！" % name)
        else:
            print("该表不存在，请从新检查输入~")
        self.data_commit()
        self.show_tables()

    def check_if_bridge_exit(self, table_name):
        sql = "show tables;"
        self.cur.execute(sql)
        tables = [self.cur.fetchall()]
        table_list = re.findall('(\'.*?\')', str(tables))
        table_list = [re.sub("'", '', each) for each in table_list]
        if table_name in table_list:
            return True  # 存在返回1
        else:
            return False
        # return True or False

########################################################################################################################
    def add_new_information_by_hand(self, name, data1, data2, data3, data4, data5, data6):
        data = [data1, data2, data3, data4, data5, data6]
        for i in range(6):
            if "==" not in data[i]:
                data[i] = "良好==10"
        # data1 = "良好==10"
        # data2 = "良好==10"
        # data3 = "良好==10"
        # data4 = "良好==10"
        # data5 = "良好==10"
        # data6 = "良好==10"
        values = (data[0], data[1], data[2], data[3], data[4], data[5])
        sentence = 'insert into %s(桥墩情况, 桥面情况, 护栏情况, 桥面排水, 桥梁高度, 桥墩卫生)' % name + \
                     'values(%s, %s, %s, %s, %s, %s) '
        self.cur.execute(sentence, values)
        self.data_commit()
        self.show_all_information(name)

        print("系统已添加本次桥梁信息。")

########################################################################################################################
    def show_tables(self):
        sentence = "show tables;"
        self.cur.execute(sentence)
        tables = [self.cur.fetchall()]
        table_list = re.findall('(\'.*?\')', str(tables))
        table_list = [re.sub("'", '', each) for each in table_list]
        # print(table_list)
        return table_list

    def show_all_information(self, name):
        sql = "select * from %s" % name
        self.cur.execute(sql)
        information = [i for i in self.cur.fetchall()]
        for i in information:
            print(i)
        # print(self.cur.fetchall())
########################################################################################################################

    def get_recent_rating(self):
        table_list = self.show_tables()
        all_rating_list = []
        finally_rating_list = []
        color_list = []
        for i in table_list:
            sql = "select 桥墩情况, 桥面情况, 护栏情况, 桥面排水, 桥梁高度, 桥墩卫生 from %s" % i
            self.cur.execute(sql)
            current_rating_list = [j for j in self.cur.fetchall()]
            all_rating_list.append(current_rating_list[-1])
        for i in all_rating_list:
            rating = 0
            for j in i:
                rating += int(j.split("==")[-1])
            finally_rating_list.append(rating)
            if rating > 52:
                color_list.append("cyan")
            elif 42 <= rating <= 52:
                color_list.append("tomato")
            else:
                color_list.append("darkred")
        data = [table_list, finally_rating_list, color_list]
        return data
        # print(len(table_list))
        # print(table_list)
        # print(len(finally_rating_list))
        # print(finally_rating_list)

########################################################################################################################
    def data_commit(self):
        self.coon.commit()

    def database_close(self):
        self.coon.close()
        self.cur.close()


if __name__ == "__main__":
    database = Database()
    # database.get_recent_rating()
    # address = '111'
    # namelist = ["铁索桥"+str(i) for i in range(100)]
    # print(namelist)
    # for name in namelist:
    #     database.delete_bridge_table(name)
    # address = "here"
    # data1 = "良好==10"
    # data2 = "良好==10"
    # data3 = "出现断裂面==10"
    # data4 = "良好==10"
    # data5 = "良好==10"
    # data6 = "良好==10"
    #
    # database.add_new_information_by_hand(name, data1, data2, data3, data4, data5, data6)
    # database.create_bridge_table(name, address)
    # database.delete_bridge_table(name)
    # database.show_all_information(name)

